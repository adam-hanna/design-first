export default class appContext {
  // note: add your app-wide context, here

}
