export default class defaultRequestContext {
  // note: add your default request context, here

}
